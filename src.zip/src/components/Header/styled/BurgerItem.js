import styled from 'styled-components';

const BurgerItem = styled.div`
  width: 100%;
  height: 4px;
  border-radius: 5px;
  background: #404040;
`;

export default BurgerItem;
import styled from 'styled-components';

const Select = styled.div`
  margin-right: 15px;
  display: flex;
`;

export default Select;
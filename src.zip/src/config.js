const config = {
    API: "https://staging.web.api.stolikapp.com/v1",
}

export {config};
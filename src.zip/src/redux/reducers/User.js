const initialState = {
  token: "eyJhbGciOiJSUzUxMiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MTMwMzA5MjAsImp0aSI6ImI5ZTJmODJmLTM1MjctNDE1NS05N2E0LTk2YjVkZDg2YTlkZCIsImlhdCI6MTYxMDQzODkyMCwiaXNzIjoic3RvbGlrYXBwLmNvbSIsInN1YiI6ImRlNjMwZjdmLTJiYmQtNGE3Ny05NmFlLTI5OGZkODViYWFmMiJ9.sHt7PTNsP4aT9IKIeOd2vjwBeAP_SS7WvJ34Z_HFXJDrQ6l4MBVDwVumKd59ozjS9ngeJkjjYEpSLCWQBDIGk7WPtZJNctkQU6wgwAMvoNSs6IWFZv_RCCoSSYwtyWjnE5Mk5YVuHOReBvNg1YyVXQWQWad5cRhhCcPSZLERwwbvEWS7KcUd4u14KR57vyEqoAXr4WqB5xGm9csedL0vUtjvQlgFDrgToY-5GciVuj15w1pLWN1f7Tp3rb7ROCPhmUgIYpUEcCy52Qge_RH9EV-OmsrSRkmxogvgOFJnMMvbd8HJHJrf6xJsybQD5N7BWzQdCzyN58upPzJ_rbo_Lg",
  user_guid: null,
}

const User = (state = initialState, action) => {
  switch (action.type) {
    default:
      return state;
  }
}

export default User;